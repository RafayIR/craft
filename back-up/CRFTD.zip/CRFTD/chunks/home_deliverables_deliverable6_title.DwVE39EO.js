import { l } from "./i18n.uwWGOJCB.js";

const r = () => "Web & Mobile Platforms",
    t = () => "Web & Mobile Platforms",
    d = (a = {}, e = {}) => ({ en: t, nl: r })[e.languageTag ?? l()](),
    i = () => "Creative Media Production",
    n = () => "Creative Media Production",
    v = (a = {}, e = {}) => ({ en: n, nl: i })[e.languageTag ?? l()](),
    s = () => "Growth Solutions", o = () => "Growth Solutions",
    b = (a = {}, e = {}) => ({ en: o, nl: s })[e.languageTag ?? l()](); export { v as a, b, d as h };
