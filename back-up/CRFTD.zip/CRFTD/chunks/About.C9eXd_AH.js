import {
    a as J,
    n as ee,
    p as z,
    j as le,
    u as se,
    k as ae,
    l as ne,
    o as Z,
    b as B,
    c as re,
    f as U
} from "./index.BH183J0c.js";
import {
    S as W,
    i as H,
    e as b,
    c as E,
    a as C,
    d as m,
    b as d,
    u as h,
    f as N,
    s as L,
    j as M,
    k as w,
    t as j,
    l as S,
    g as O,
    h as P,
    m as $,
    n as F,
    y as X,
    o as oe,
    p as fe,
    B as ue
} from "./index.B5pbiKnB.js";
import {
    g as A,
    F as Y
} from "./gsap.BWqxc2AZ.js";
import {
    p as ce
} from "./app.Cgy8eObc.js";
import {
    T as Q
} from "./TitleReveal.SbfJCpuF.js";
import {
    L as ge,
    P as G,
    a as de,
    A as ie
} from "./projects.Boais4ol.js";
import {
    i as he
} from "./i18n.uwWGOJCB.js";
import {
    g as me
} from "./entry.B4BmtFq6.js";

function _e(a) {
    let e, s;
    return {
        c() {
            e = b("video"), this.h()
        },
        l(l) {
            e = E(l, "VIDEO", {
                src: !0,
                class: !0
            }), C(e).forEach(m), this.h()
        },
        h() {
            z(e.src, s = a[1]) || d(e, "src", s), d(e, "class", "h-full w-full object-cover"), e.autoplay = !0, e.muted = !0, e.playsInline = !0, e.loop = !0
        },
        m(l, t) {
            N(l, e, t)
        },
        p(l, t) {
            t & 2 && !z(e.src, s = l[1]) && d(e, "src", s)
        },
        d(l) {
            l && m(e)
        }
    }
}

function ve(a) {
    let e, s, l;
    return {
        c() {
            e = b("img"), this.h()
        },
        l(t) {
            e = E(t, "IMG", {
                class: !0,
                src: !0,
                alt: !0
            }), this.h()
        },
        h() {
            d(e, "class", "w-full object-cover"), z(e.src, s = a[0].src) || d(e, "src", s), d(e, "alt", l = a[0].alt), h(e, "h-[24vh]", a[3] === "screen"), h(e, "l:h-screen", a[3] === "screen"), h(e, "h-auto", a[3] === "auto")
        },
        m(t, n) {
            N(t, e, n)
        },
        p(t, n) {
            n & 1 && !z(e.src, s = t[0].src) && d(e, "src", s), n & 1 && l !== (l = t[0].alt) && d(e, "alt", l), n & 8 && h(e, "h-[24vh]", t[3] === "screen"), n & 8 && h(e, "l:h-screen", t[3] === "screen"), n & 8 && h(e, "h-auto", t[3] === "auto")
        },
        d(t) {
            t && m(e)
        }
    }
}

function pe(a) {
    let e, s;

    function l(i, o) {
        if (i[0]) return ve;
        if (i[1]) return _e
    }
    let t = l(a),
        n = t && t(a);
    return {
        c() {
            e = b("div"), n && n.c(), this.h()
        },
        l(i) {
            e = E(i, "DIV", {
                class: !0
            });
            var o = C(e);
            n && n.l(o), o.forEach(m), this.h()
        },
        h() {
            d(e, "class", s = "module-visual " + a[4]), h(e, "col-span-full", a[2] === "12" || a[2] === "8" || a[2] === "screen"), h(e, "l:col-span-8", a[2] === "8"), h(e, "l:col-start-3", a[2] === "8"), h(e, "col-span-6", a[2] === "6"), h(e, "extend-both", a[2] === "screen")
        },
        m(i, o) {
            N(i, e, o), n && n.m(e, null)
        },
        p(i, [o]) {
            t === (t = l(i)) && n ? n.p(i, o) : (n && n.d(1), n = t && t(i), n && (n.c(), n.m(e, null))), o & 16 && s !== (s = "module-visual " + i[4]) && d(e, "class", s), o & 20 && h(e, "col-span-full", i[2] === "12" || i[2] === "8" || i[2] === "screen"), o & 20 && h(e, "l:col-span-8", i[2] === "8"), o & 20 && h(e, "l:col-start-3", i[2] === "8"), o & 20 && h(e, "col-span-6", i[2] === "6"), o & 20 && h(e, "extend-both", i[2] === "screen")
        },
        i: ee,
        o: ee,
        d(i) {
            i && m(e), n && n.d()
        }
    }
}

function be(a, e, s) {
    let {
        visual: l = null
    } = e, {
        video: t = null
    } = e, {
        span: n
    } = e, {
        height: i = "auto"
    } = e, {
        class: o = ""
    } = e;
    return a.$$set = r => {
        "visual" in r && s(0, l = r.visual), "video" in r && s(1, t = r.video), "span" in r && s(2, n = r.span), "height" in r && s(3, i = r.height), "class" in r && s(4, o = r.class)
    }, [l, t, n, i, o]
}
class Re extends W {
    constructor(e) {
        super(), H(this, e, be, pe, J, {
            visual: 0,
            video: 1,
            span: 2,
            height: 3,
            class: 4
        })
    }
}

function te(a) {
    let e, s, l;
    return {
        c() {
            e = b("img"), this.h()
        },
        l(t) {
            e = E(t, "IMG", {
                class: !0,
                src: !0,
                alt: !0
            }), this.h()
        },
        h() {
            d(e, "class", "absolute top-0 h-full w-full"), z(e.src, s = a[4].src) || d(e, "src", s), d(e, "alt", l = a[4].alt)
        },
        m(t, n) {
            N(t, e, n), a[9](e)
        },
        p(t, n) {
            n & 16 && !z(e.src, s = t[4].src) && d(e, "src", s), n & 16 && l !== (l = t[4].alt) && d(e, "alt", l)
        },
        d(t) {
            t && m(e), a[9](null)
        }
    }
}

function Ee(a) {
    let e, s, l, t, n, i = a[4] && te(a);
    const o = a[8].default,
        r = le(o, a, a[7], null);
    return {
        c() {
            e = b("div"), i && i.c(), s = L(), l = b("div"), r && r.c(), this.h()
        },
        l(f) {
            e = E(f, "DIV", {
                class: !0
            });
            var g = C(e);
            i && i.l(g), s = M(g), l = E(g, "DIV", {
                class: !0
            });
            var c = C(l);
            r && r.l(c), c.forEach(m), g.forEach(m), this.h()
        },
        h() {
            d(l, "class", "container content-grid relative"), h(l, "gap-y-fluid-2xl-5xl", a[2] === "5xl"), d(e, "class", t = "module-visual-grid relative overflow-hidden " + a[3]), h(e, "bg-black", a[0] === "black"), h(e, "bg-white", a[0] === "white"), h(e, "bg-green", a[0] === "green"), h(e, "bg-venturedge", a[0] === "venturedge"), h(e, "py-fluid-2xl-5xl", a[1] === "5xl"), h(e, "pt-grid-gap", a[1] === "grid-t" || a[1] === "grid-y"), h(e, "pb-grid-gap", a[1] === "grid-b" || a[1] === "grid-y")
        },
        m(f, g) {
            N(f, e, g), i && i.m(e, null), w(e, s), w(e, l), r && r.m(l, null), a[10](e), n = !0
        },
        p(f, [g]) {
            f[4] ? i ? i.p(f, g) : (i = te(f), i.c(), i.m(e, s)) : i && (i.d(1), i = null), r && r.p && (!n || g & 128) && se(r, o, f, f[7], n ? ne(o, f[7], g, null) : ae(f[7]), null), (!n || g & 4) && h(l, "gap-y-fluid-2xl-5xl", f[2] === "5xl"), (!n || g & 8 && t !== (t = "module-visual-grid relative overflow-hidden " + f[3])) && d(e, "class", t), (!n || g & 9) && h(e, "bg-black", f[0] === "black"), (!n || g & 9) && h(e, "bg-white", f[0] === "white"), (!n || g & 9) && h(e, "bg-green", f[0] === "green"), (!n || g & 9) && h(e, "bg-venturedge", f[0] === "venturedge"), (!n || g & 10) && h(e, "py-fluid-2xl-5xl", f[1] === "5xl"), (!n || g & 10) && h(e, "pt-grid-gap", f[1] === "grid-t" || f[1] === "grid-y"), (!n || g & 10) && h(e, "pb-grid-gap", f[1] === "grid-b" || f[1] === "grid-y")
        },
        i(f) {
            n || (j(r, f), n = !0)
        },
        o(f) {
            S(r, f), n = !1
        },
        d(f) {
            f && m(e), i && i.d(), r && r.d(f), a[10](null)
        }
    }
}

function Ie(a, e, s) {
    let {
        $$slots: l = {},
        $$scope: t
    } = e, {
        theme: n = "black"
    } = e, {
        spacing: i = "none"
    } = e, {
        gap: o = "grid"
    } = e, {
        class: r = ""
    } = e, {
        visual: f = null
    } = e, g, c;
    Z(() => {
        let u = A.context(() => {
            f && (A.set(c, {
                scale: 1.1,
                transformOrigin: "top"
            }), A.to(c, {
                yPercent: -10,
                scrollTrigger: {
                    trigger: g,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: !0
                }
            }))
        });
        return () => u.revert()
    });

    function v(u) {
        B[u ? "unshift" : "push"](() => {
            c = u, s(6, c)
        })
    }

    function I(u) {
        B[u ? "unshift" : "push"](() => {
            g = u, s(5, g)
        })
    }
    return a.$$set = u => {
        "theme" in u && s(0, n = u.theme), "spacing" in u && s(1, i = u.spacing), "gap" in u && s(2, o = u.gap), "class" in u && s(3, r = u.class), "visual" in u && s(4, f = u.visual), "$$scope" in u && s(7, t = u.$$scope)
    }, [n, i, o, r, f, g, c, t, l, v, I]
}
class qe extends W {
    constructor(e) {
        super(), H(this, e, Ie, Ee, J, {
            theme: 0,
            spacing: 1,
            gap: 2,
            class: 3,
            visual: 4
        })
    }
}

function we(a) {
    let e, s, l, t, n, i, o, r, f, g, c, v, I;
    return f = new Q({
        props: {
            trigger: !1,
            fire: a[2],
            theme: "green",
            size: "xs",
            content: ["Case"]
        }
    }), v = new Q({
        props: {
            tag: "h1",
            trigger: !1,
            fire: a[2],
            theme: "black",
            size: "2xl",
            content: a[1]
        }
    }), {
        c() {
            e = b("section"), s = b("div"), l = b("img"), i = L(), o = b("div"), r = b("div"), O(f.$$.fragment), g = L(), c = b("div"), O(v.$$.fragment), this.h()
        },
        l(u) {
            e = E(u, "SECTION", {
                class: !0
            });
            var k = C(e);
            s = E(k, "DIV", {
                class: !0
            });
            var T = C(s);
            l = E(T, "IMG", {
                class: !0,
                src: !0,
                alt: !0
            }), T.forEach(m), i = M(k), o = E(k, "DIV", {
                class: !0
            });
            var p = C(o);
            r = E(p, "DIV", {
                class: !0
            });
            var R = C(r);
            P(f.$$.fragment, R), g = M(R), c = E(R, "DIV", {});
            var q = C(c);
            P(v.$$.fragment, q), q.forEach(m), R.forEach(m), p.forEach(m), k.forEach(m), this.h()
        },
        h() {
            d(l, "class", "absolute h-full w-full object-cover"), z(l.src, t = a[0].src) || d(l, "src", t), d(l, "alt", n = a[0].alt), d(s, "class", "absolute inset-0"), d(r, "class", "col-span-full flex flex-col gap-y-fluid-3xs"), d(o, "class", "container content-grid"), d(e, "class", "module-case-splash relative flex h-screen items-end pb-fluid-l-xl")
        },
        m(u, k) {
            N(u, e, k), w(e, s), w(s, l), w(e, i), w(e, o), w(o, r), $(f, r, null), w(r, g), w(r, c), $(v, c, null), I = !0
        },
        p(u, [k]) {
            (!I || k & 1 && !z(l.src, t = u[0].src)) && d(l, "src", t), (!I || k & 1 && n !== (n = u[0].alt)) && d(l, "alt", n);
            const T = {};
            k & 4 && (T.fire = u[2]), f.$set(T);
            const p = {};
            k & 4 && (p.fire = u[2]), k & 2 && (p.content = u[1]), v.$set(p)
        },
        i(u) {
            I || (j(f.$$.fragment, u), j(v.$$.fragment, u), I = !0)
        },
        o(u) {
            S(f.$$.fragment, u), S(v.$$.fragment, u), I = !1
        },
        d(u) {
            u && m(e), F(f), F(v)
        }
    }
}

function ke(a, e, s) {
    let l, t;
    re(a, ce, r => s(4, t = r));
    let {
        thumbnail: n
    } = e, {
        title: i = []
    } = e, o = !1;
    return Z(() => {
        s(3, o = !0)
    }), a.$$set = r => {
        "thumbnail" in r && s(0, n = r.thumbnail), "title" in r && s(1, i = r.title)
    }, a.$$.update = () => {
        a.$$.dirty & 24 && s(2, l = o && !t)
    }, [n, i, l, o, t]
}
class Be extends W {
    constructor(e) {
        super(), H(this, e, ke, we, J, {
            thumbnail: 0,
            title: 1
        })
    }
}

function Ce(a) {
    let e, s, l, t, n, i, o, r, f, g, c, v, I, u;

    function k(_) {
        a[6](_)
    }
    let T = {};
    a[2] !== void 0 && (T.logoEl = a[2]), l = new ge({
        props: T
    }), B.push(() => X(l, "logoEl", k)), r = new Q({
        props: {
            content: ["Next", "case"]
        }
    });

    function p(_) {
        a[7](_)
    }

    function R(_) {
        a[8](_)
    }
    let q = {
        thumbnail: G()[a[0]].thumbnail,
        title: G()[a[0]].title,
        tag: G()[a[0]].tag
    };
    return a[3] !== void 0 && (q.cardImageEl = a[3]), a[4] !== void 0 && (q.overlayCardImageEl = a[4]), c = new de({
        props: q
    }), B.push(() => X(c, "cardImageEl", p)), B.push(() => X(c, "overlayCardImageEl", R)), c.$on("click", a[9]), {
        c() {
            e = b("section"), s = b("div"), O(l.$$.fragment), n = L(), i = b("div"), o = b("div"), O(r.$$.fragment), f = L(), g = b("div"), O(c.$$.fragment), this.h()
        },
        l(_) {
            e = E(_, "SECTION", {
                class: !0
            });
            var V = C(e);
            s = E(V, "DIV", {
                class: !0
            });
            var K = C(s);
            P(l.$$.fragment, K), K.forEach(m), n = M(V), i = E(V, "DIV", {
                class: !0
            });
            var D = C(i);
            o = E(D, "DIV", {
                class: !0
            });
            var y = C(o);
            P(r.$$.fragment, y), y.forEach(m), f = M(D), g = E(D, "DIV", {
                class: !0
            });
            var x = C(g);
            P(c.$$.fragment, x), x.forEach(m), D.forEach(m), V.forEach(m), this.h()
        },
        h() {
            d(s, "class", "pointer-events-none absolute top-1/2 w-full -translate-y-1/2 fill-black/5 max-l:scale-200"), d(o, "class", "col-span-full l:col-span-2"), d(g, "class", "col-span-full l:col-span-4 l:col-start-5"), d(i, "class", "container content-grid gap-y-fluid-l"), d(e, "class", "module-next relative flex h-screen items-center overflow-hidden bg-white")
        },
        m(_, V) {
            N(_, e, V), w(e, s), $(l, s, null), w(e, n), w(e, i), w(i, o), $(r, o, null), w(i, f), w(i, g), $(c, g, null), a[10](e), u = !0
        },
        p(_, [V]) {
            const K = {};
            !t && V & 4 && (t = !0, K.logoEl = _[2], U(() => t = !1)), l.$set(K);
            const D = {};
            V & 1 && (D.thumbnail = G()[_[0]].thumbnail), V & 1 && (D.title = G()[_[0]].title), V & 1 && (D.tag = G()[_[0]].tag), !v && V & 8 && (v = !0, D.cardImageEl = _[3], U(() => v = !1)), !I && V & 16 && (I = !0, D.overlayCardImageEl = _[4], U(() => I = !1)), c.$set(D)
        },
        i(_) {
            u || (j(l.$$.fragment, _), j(r.$$.fragment, _), j(c.$$.fragment, _), u = !0)
        },
        o(_) {
            S(l.$$.fragment, _), S(r.$$.fragment, _), S(c.$$.fragment, _), u = !1
        },
        d(_) {
            _ && m(e), F(l), F(r), F(c), a[10](null)
        }
    }
}

function Ve(a, e, s) {
    let {
        nextCaseIndex: l
    } = e, t, n, i, o, r;
    const f = () => {
            r == null || r.add(() => {
                o.classList.remove("hidden"), Y.Flip.fit(o, i);
                const p = Y.Flip.getState(o);
                A.set(o, {
                    clearProps: !0
                }), A.set(o, {
                    width: "100vw",
                    height: "100vh",
                    top: 0,
                    left: 0
                }), Y.Flip.from(p, {
                    duration: .8,
                    ease: "power2.inOut",
                    onComplete: () => {
                        c(l)
                    }
                }), A.to(o, {
                    clipPath: "polygon(0px 0, 100% 0, 100% 100%, 0 100%, 0 0px)",
                    duration: .8,
                    ease: "power2.inOut"
                })
            }, t)
        },
        g = () => {
            r == null || r.add(() => {
                A.to(n, {
                    yPercent: 40,
                    ease: "none",
                    scrollTrigger: {
                        trigger: t,
                        start: "top bottom",
                        end: "bottom 20%",
                        scrub: !0
                    }
                })
            }, t)
        },
        c = p => {
            me(he.resolveRoute(`/${G()[p].href}`))
        };
    Z(() => (r == null || r.revert(), r = A.context(() => {}, t), g(), () => r == null ? void 0 : r.revert()));

    function v(p) {
        n = p, s(2, n)
    }

    function I(p) {
        i = p, s(3, i)
    }

    function u(p) {
        o = p, s(4, o)
    }
    const k = () => f();

    function T(p) {
        B[p ? "unshift" : "push"](() => {
            t = p, s(1, t)
        })
    }
    return a.$$set = p => {
        "nextCaseIndex" in p && s(0, l = p.nextCaseIndex)
    }, [l, t, n, i, o, f, v, I, u, k, T]
}
class Je extends W {
    constructor(e) {
        super(), H(this, e, Ve, Ce, J, {
            nextCaseIndex: 0
        })
    }
}

function De(a) {
    let e;
    const s = a[0].default,
        l = le(s, a, a[1], null);
    return {
        c() {
            l && l.c()
        },
        l(t) {
            l && l.l(t)
        },
        m(t, n) {
            l && l.m(t, n), e = !0
        },
        p(t, n) {
            l && l.p && (!e || n & 2) && se(l, s, t, t[1], e ? ne(s, t[1], n, null) : ae(t[1]), null)
        },
        i(t) {
            e || (j(l, t), e = !0)
        },
        o(t) {
            S(l, t), e = !1
        },
        d(t) {
            l && l.d(t)
        }
    }
}

function je(a) {
    let e, s, l, t, n;
    return t = new ie({
        props: {
            $$slots: {
                default: [De]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            e = b("section"), s = b("div"), l = b("div"), O(t.$$.fragment), this.h()
        },
        l(i) {
            e = E(i, "SECTION", {
                class: !0
            });
            var o = C(e);
            s = E(o, "DIV", {
                class: !0
            });
            var r = C(s);
            l = E(r, "DIV", {
                class: !0
            });
            var f = C(l);
            P(t.$$.fragment, f), f.forEach(m), r.forEach(m), o.forEach(m), this.h()
        },
        h() {
            d(l, "class", "col-span-full l:col-span-8"), d(s, "class", "container content-grid"), d(e, "class", "module-context bg-black pb-fluid-2xl-6xl pt-fluid-3xl-4xl text-white")
        },
        m(i, o) {
            N(i, e, o), w(e, s), w(s, l), $(t, l, null), n = !0
        },
        p(i, [o]) {
            const r = {};
            o & 2 && (r.$$scope = {
                dirty: o,
                ctx: i
            }), t.$set(r)
        },
        i(i) {
            n || (j(t.$$.fragment, i), n = !0)
        },
        o(i) {
            S(t.$$.fragment, i), n = !1
        },
        d(i) {
            i && m(e), F(t)
        }
    }
}

function Se(a, e, s) {
    let {
        $$slots: l = {},
        $$scope: t
    } = e;
    return a.$$set = n => {
        "$$scope" in n && s(1, t = n.$$scope)
    }, [l, t]
}
class We extends W {
    constructor(e) {
        super(), H(this, e, Se, je, J, {})
    }
}

function Te(a) {
    let e;
    return {
        c() {
            e = oe(a[0])
        },
        l(s) {
            e = fe(s, a[0])
        },
        m(s, l) {
            N(s, e, l)
        },
        p(s, l) {
            l & 1 && ue(e, s[0])
        },
        d(s) {
            s && m(e)
        }
    }
}

function Ne(a) {
    let e, s, l, t, n, i, o, r, f, g;
    return t = new Q({
        props: {
            theme: "white",
            size: "xs",
            content: ["About"]
        }
    }), o = new ie({
        props: {
            $$slots: {
                default: [Te]
            },
            $$scope: {
                ctx: a
            }
        }
    }), f = new Q({
        props: {
            theme: "black",
            size: "xs",
            content: a[1]
        }
    }), {
        c() {
            e = b("section"), s = b("div"), l = b("div"), O(t.$$.fragment), n = L(), i = b("div"), O(o.$$.fragment), r = L(), O(f.$$.fragment), this.h()
        },
        l(c) {
            e = E(c, "SECTION", {
                class: !0
            });
            var v = C(e);
            s = E(v, "DIV", {
                class: !0
            });
            var I = C(s);
            l = E(I, "DIV", {
                class: !0
            });
            var u = C(l);
            P(t.$$.fragment, u), u.forEach(m), n = M(I), i = E(I, "DIV", {
                class: !0
            });
            var k = C(i);
            P(o.$$.fragment, k), r = M(k), P(f.$$.fragment, k), k.forEach(m), I.forEach(m), v.forEach(m), this.h()
        },
        h() {
            d(l, "class", "col-span-full l:col-span-4"), d(i, "class", "col-span-full flex flex-col gap-y-fluid-xl l:col-span-8 l:col-start-5"), d(s, "class", "container content-grid"), d(e, "class", "bg-black pb-fluid-3xl-5xl pt-fluid-l-xl text-white")
        },
        m(c, v) {
            N(c, e, v), w(e, s), w(s, l), $(t, l, null), w(s, n), w(s, i), $(o, i, null), w(i, r), $(f, i, null), g = !0
        },
        p(c, [v]) {
            const I = {};
            v & 5 && (I.$$scope = {
                dirty: v,
                ctx: c
            }), o.$set(I);
            const u = {};
            v & 2 && (u.content = c[1]), f.$set(u)
        },
        i(c) {
            g || (j(t.$$.fragment, c), j(o.$$.fragment, c), j(f.$$.fragment, c), g = !0)
        },
        o(c) {
            S(t.$$.fragment, c), S(o.$$.fragment, c), S(f.$$.fragment, c), g = !1
        },
        d(c) {
            c && m(e), F(t), F(o), F(f)
        }
    }
}

function Oe(a, e, s) {
    let {
        content: l
    } = e, {
        tags: t = []
    } = e;
    return a.$$set = n => {
        "content" in n && s(0, l = n.content), "tags" in n && s(1, t = n.tags)
    }, [l, t]
}
class He extends W {
    constructor(e) {
        super(), H(this, e, Oe, Ne, J, {
            content: 0,
            tags: 1
        })
    }
}
export {
    He as A, We as C, Je as N, Be as S, qe as V, Re as a
};
