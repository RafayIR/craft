import {
    l as a
} from "./i18n.uwWGOJCB.js";
const s = () => "Managed IT Services",
    t = () => "Managed IT Services",
    b = (l = {}, e = {}) => ({
        en: t,
        nl: s
    })[e.languageTag ?? a()](),
    n = () => "Cloud Integration",
    i = () => "Cloud Integration",
    d = (l = {}, e = {}) => ({
        en: i,
        nl: n
    })[e.languageTag ?? a()](),
    r = () => "Digital Strategy",
    o = () => "Digital Strategy",
    p = (l = {}, e = {}) => ({
        en: o,
        nl: r
    })[e.languageTag ?? a()]();
export {
    d as a, p as b, b as h
};
