const r = {
    inherit: "inherit",
    current: "currentColor",
    transparent: "transparent",
    white: "#ffffff",
    black: "#000000",
    purple: "#9c91f7",
    darkgrey: "#141414",
    green: "#00ff00",
    // green: "#ccc",
    pink: "#ff00ff",
    red: "#E02424",
    venturedge: "#242736"
},



    e = { ...r, primary: r.purple, secondary: r.green, tertiary: r.pink }; export { e as c };

