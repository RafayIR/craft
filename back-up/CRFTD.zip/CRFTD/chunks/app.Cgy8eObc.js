import { w as o } from "./index.BH183J0c.js";
const s = o(!0), t = o(!1); 

export { t as f, s as p };
