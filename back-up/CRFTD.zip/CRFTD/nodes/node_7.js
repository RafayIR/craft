import {
    a as ae,
    n as K
} from "../chunks/index.BH183J0c.js";
import {
    S as se,
    i as ue,
    e as U,
    s as E,
    g as o,
    G as me,
    c as y,
    d as $,
    j as k,
    h as l,
    b as _,
    k as A,
    f as b,
    m as p,
    t as g,
    l as f,
    n as d,
    o as $e,
    p as ie
} from "../chunks/index.B5pbiKnB.js";
import {
    S as oe,
    A as le,
    V as B,
    C as pe,
    N as ge,
    a as x
} from "../chunks/About.C9eXd_AH.js";
import {
    h as fe,
    a as de,
    b as ve
} from "../chunks/home_deliverables_deliverable6_title.DwVE39EO.js";
import {
    l as Q
} from "../chunks/i18n.uwWGOJCB.js";
const ce = () => "CRFTD - SERVICE 4",
    _e = () => "CRFTD - SERVICE 4",
    ne = (R = {}, t = {}) => ({
        en: _e,
        nl: ce
    })[t.languageTag ?? Q()](),
    we = () => "Ontdek hoe CRFTD een innovatief webdesign creëerde voor Project3, waardoor hun online aanwezigheid en klantbetrokkenheid drastisch verbeterden.",
    he = () => "VenturEdge – a brand that breathes adventure. You can feel it in the branding. Bold. Rugged. Premium. And that’s exactly what VenturEdge is.",
    re = (R = {}, t = {}) => ({
        en: he,
        nl: we
    })[t.languageTag ?? Q()](),
    be = () => "VenturEdge – een merk dat avontuur ademt. En dat voel je. Tussen een overkill van aanbieders hebben wij VenturEdge – door zijn krachtig ontwikkelde merkidentiteit – stevig op de kaart gezet. De perfect uitgewerkte branding toont precies de definitie van VenturEdge; premium kleding en gear voor de échte buitenmens.",
    Ee = () => "VenturEdge – a brand that breathes adventure. And you can feel it. Amidst a sea of competitors, we’ve firmly positioned VenturEdge on the map through its powerfully developed brand identity. The meticulously crafted branding perfectly reflects what VenturEdge stands for: premium clothing and gear for true outdoor enthusiasts.",
    ke = (R = {}, t = {}) => ({
        en: Ee,
        nl: be
    })[t.languageTag ?? Q()](),
    Re = () => "Van robuuste jassen voor ijskoude hikes tot winddichte tenten voor wildkamperen; alles ontworpen en gemaakt voor ultieme prestaties in iedere omgeving. VenturEdge is voor de avonturier. Niets houdt hem tegen. Niets laat hem stoppen. Can't hold us down.",
    Te = () => "From rugged jackets for freezing hikes to windproof tents for wild camping; everything is designed and built for ultimate performance in any environment. VenturEdge is for the adventurer. Nothing holds them back. Nothing makes them stop. Can’t hold us down.",
    xe = (R = {}, t = {}) => ({
        en: Te,
        nl: Re
    })[t.languageTag ?? Q()](),
    Ve = "" + new URL("../assets/venturedge_hero.BV2wo8l-.jpg", import.meta.url).href,
    Ce = "" + new URL("../assets/venturedge_14.C2zK173Q.webp", import.meta.url).href,
    Ue = "" + new URL("../assets/venturedge_13.BrhZJUA5.webp", import.meta.url).href,
    ye = "" + new URL("../assets/venturedge_12.Iys7WiHz.webp", import.meta.url).href,
    Ae = "" + new URL("../assets/venturedge_11.DpCdGgoD.webp", import.meta.url).href,
    Le = "" + new URL("../assets/venturedge_10.vsplPFWq.webp", import.meta.url).href,
    De = "" + new URL("../assets/venturedge_9.CYl9K0RK.webp", import.meta.url).href,
    Fe = "" + new URL("../assets/venturedge_8.CoNfughK.webp", import.meta.url).href,
    je = "" + new URL("../assets/venturedge_7.CDtScsNQ.webp", import.meta.url).href,
    Me = "" + new URL("../assets/venturedge_6.BUGVhgeO.webp", import.meta.url).href,
    Ne = "" + new URL("../assets/venturedge_5.BEHKoGZI.webp", import.meta.url).href,
    ze = "" + new URL("../assets/venturedge_4.D9Rvti26.webp", import.meta.url).href,
    Ke = "" + new URL("../assets/venturedge_3.DvliU5zl.webp", import.meta.url).href,
    Be = "" + new URL("../assets/venturedge_2.CAriZTFX.webp", import.meta.url).href,
    Ge = "" + new URL("../assets/venturedge_1.BFFC46uK.webp", import.meta.url).href;

function Se(R) {
    let t, m, n, i, u, c, v, T;
    return t = new x({
        props: {
            visual: {
                src: Ge,
                alt: ""
            },
            span: "12",
            height: "screen"
        }
    }), n = new x({
        props: {
            visual: {
                src: Be,
                alt: ""
            },
            span: "6",
            height: "auto"
        }
    }), u = new x({
        props: {
            visual: {
                src: Ke,
                alt: ""
            },
            span: "6",
            height: "auto"
        }
    }), v = new x({
        props: {
            visual: {
                src: ze,
                alt: ""
            },
            span: "screen",
            height: "auto"
        }
    }), {
        c() {
            o(t.$$.fragment), m = E(), o(n.$$.fragment), i = E(), o(u.$$.fragment), c = E(), o(v.$$.fragment)
        },
        l(a) {
            l(t.$$.fragment, a), m = k(a), l(n.$$.fragment, a), i = k(a), l(u.$$.fragment, a), c = k(a), l(v.$$.fragment, a)
        },
        m(a, w) {
            p(t, a, w), b(a, m, w), p(n, a, w), b(a, i, w), p(u, a, w), b(a, c, w), p(v, a, w), T = !0
        },
        p: K,
        i(a) {
            T || (g(t.$$.fragment, a), g(n.$$.fragment, a), g(u.$$.fragment, a), g(v.$$.fragment, a), T = !0)
        },
        o(a) {
            f(t.$$.fragment, a), f(n.$$.fragment, a), f(u.$$.fragment, a), f(v.$$.fragment, a), T = !1
        },
        d(a) {
            a && ($(m), $(i), $(c)), d(t, a), d(n, a), d(u, a), d(v, a)
        }
    }
}

function Ie(R) {
    let t, m;
    return t = new x({
        props: {
            visual: {
                src: Ne,
                alt: ""
            },
            span: "12",
            height: "auto"
        }
    }), {
        c() {
            o(t.$$.fragment)
        },
        l(n) {
            l(t.$$.fragment, n)
        },
        m(n, i) {
            p(t, n, i), m = !0
        },
        p: K,
        i(n) {
            m || (g(t.$$.fragment, n), m = !0)
        },
        o(n) {
            f(t.$$.fragment, n), m = !1
        },
        d(n) {
            d(t, n)
        }
    }
}

function Pe(R) {
    let t, m, n, i;
    return t = new x({
        props: {
            visual: {
                src: Me,
                alt: ""
            },
            span: "8",
            height: "auto"
        }
    }), n = new x({
        props: {
            visual: {
                src: je,
                alt: ""
            },
            span: "screen",
            height: "auto"
        }
    }), {
        c() {
            o(t.$$.fragment), m = E(), o(n.$$.fragment)
        },
        l(u) {
            l(t.$$.fragment, u), m = k(u), l(n.$$.fragment, u)
        },
        m(u, c) {
            p(t, u, c), b(u, m, c), p(n, u, c), i = !0
        },
        p: K,
        i(u) {
            i || (g(t.$$.fragment, u), g(n.$$.fragment, u), i = !0)
        },
        o(u) {
            f(t.$$.fragment, u), f(n.$$.fragment, u), i = !1
        },
        d(u) {
            u && $(m), d(t, u), d(n, u)
        }
    }
}

function qe(R) {
    let t, m;
    return t = new x({
        props: {
            visual: {
                src: Fe,
                alt: ""
            },
            span: "12",
            height: "auto"
        }
    }), {
        c() {
            o(t.$$.fragment)
        },
        l(n) {
            l(t.$$.fragment, n)
        },
        m(n, i) {
            p(t, n, i), m = !0
        },
        p: K,
        i(n) {
            m || (g(t.$$.fragment, n), m = !0)
        },
        o(n) {
            f(t.$$.fragment, n), m = !1
        },
        d(n) {
            d(t, n)
        }
    }
}

function Ze(R) {
    let t = xe() + "",
        m;
    return {
        c() {
            m = $e(t)
        },
        l(n) {
            m = ie(n, t)
        },
        m(n, i) {
            b(n, m, i)
        },
        p: K,
        d(n) {
            n && $(m)
        }
    }
}

function He(R) {
    let t, m, n, i, u, c, v, T, a, w, V, C;
    return t = new x({
        props: {
            visual: {
                src: De,
                alt: ""
            },
            span: "12",
            height: "auto"
        }
    }), n = new x({
        props: {
            visual: {
                src: Le,
                alt: ""
            },
            span: "6",
            height: "auto"
        }
    }), u = new x({
        props: {
            visual: {
                src: Ae,
                alt: ""
            },
            span: "6",
            height: "auto",
            class: "mt-fluid-2xl-5xl"
        }
    }), v = new x({
        props: {
            visual: {
                src: ye,
                alt: ""
            },
            span: "screen",
            height: "auto"
        }
    }), a = new x({
        props: {
            visual: {
                src: Ue,
                alt: ""
            },
            span: "6",
            height: "auto"
        }
    }), V = new x({
        props: {
            visual: {
                src: Ce,
                alt: ""
            },
            span: "6",
            height: "auto"
        }
    }), {
        c() {
            o(t.$$.fragment), m = E(), o(n.$$.fragment), i = E(), o(u.$$.fragment), c = E(), o(v.$$.fragment), T = E(), o(a.$$.fragment), w = E(), o(V.$$.fragment)
        },
        l(r) {
            l(t.$$.fragment, r), m = k(r), l(n.$$.fragment, r), i = k(r), l(u.$$.fragment, r), c = k(r), l(v.$$.fragment, r), T = k(r), l(a.$$.fragment, r), w = k(r), l(V.$$.fragment, r)
        },
        m(r, h) {
            p(t, r, h), b(r, m, h), p(n, r, h), b(r, i, h), p(u, r, h), b(r, c, h), p(v, r, h), b(r, T, h), p(a, r, h), b(r, w, h), p(V, r, h), C = !0
        },
        p: K,
        i(r) {
            C || (g(t.$$.fragment, r), g(n.$$.fragment, r), g(u.$$.fragment, r), g(v.$$.fragment, r), g(a.$$.fragment, r), g(V.$$.fragment, r), C = !0)
        },
        o(r) {
            f(t.$$.fragment, r), f(n.$$.fragment, r), f(u.$$.fragment, r), f(v.$$.fragment, r), f(a.$$.fragment, r), f(V.$$.fragment, r), C = !1
        },
        d(r) {
            r && ($(m), $(i), $(c), $(T), $(w)), d(t, r), d(n, r), d(u, r), d(v, r), d(a, r), d(V, r)
        }
    }
}

function Oe(R) {
    let t, m, n, i, u, c, v, T, a, w, V, C, r, h, G, L, S, D, I, F, P, j, q, M, Z, N, H, z, O;
    return document.title = ne(), C = new oe({
        props: {
            thumbnail: {
                src: Ve,
                alt: "VenturEdge hero"
            },
            title: ["VenturEdge"]
        }
    }), h = new le({
        props: {
            content: ke(),
            tags: [fe(), de(), ve()]
        }
    }), L = new B({
        props: {
            $$slots: {
                default: [Se]
            },
            $$scope: {
                ctx: R
            }
        }
    }), D = new B({
        props: {
            spacing: "grid-t",
            theme: "venturedge",
            $$slots: {
                default: [Ie]
            },
            $$scope: {
                ctx: R
            }
        }
    }), F = new B({
        props: {
            class: "pt-fluid-2xl-5xl",
            gap: "5xl",
            theme: "venturedge",
            $$slots: {
                default: [Pe]
            },
            $$scope: {
                ctx: R
            }
        }
    }), j = new B({
        props: {
            class: "mt-fluid-l-3xl",
            $$slots: {
                default: [qe]
            },
            $$scope: {
                ctx: R
            }
        }
    }), M = new pe({
        props: {
            $$slots: {
                default: [Ze]
            },
            $$scope: {
                ctx: R
            }
        }
    }), N = new B({
        props: {
            class: "mb-fluid-2xl-5xl",
            $$slots: {
                default: [He]
            },
            $$scope: {
                ctx: R
            }
        }
    }), z = new ge({
        props: {
            nextCaseIndex: 0
        }
    }), {
        c() {
            t = U("meta"), m = U("meta"), n = U("meta"), i = U("meta"), u = U("meta"), c = U("meta"), v = U("meta"), T = U("link"), a = U("meta"), w = U("meta"), V = E(), o(C.$$.fragment), r = E(), o(h.$$.fragment), G = E(), o(L.$$.fragment), S = E(), o(D.$$.fragment), I = E(), o(F.$$.fragment), P = E(), o(j.$$.fragment), q = E(), o(M.$$.fragment), Z = E(), o(N.$$.fragment), H = E(), o(z.$$.fragment), this.h()
        },
        l(e) {
            const s = me("svelte-1ry3qle", document.head);
            t = y(s, "META", {
                name: !0,
                content: !0
            }), m = y(s, "META", {
                property: !0,
                content: !0
            }), n = y(s, "META", {
                property: !0,
                content: !0
            }), i = y(s, "META", {
                property: !0,
                content: !0
            }), u = y(s, "META", {
                property: !0,
                content: !0
            }), c = y(s, "META", {
                property: !0,
                content: !0
            }), v = y(s, "META", {
                property: !0,
                content: !0
            }), T = y(s, "LINK", {
                rel: !0,
                href: !0
            }), a = y(s, "META", {
                name: !0,
                content: !0
            }), w = y(s, "META", {
                name: !0,
                content: !0
            }), s.forEach($), V = k(e), l(C.$$.fragment, e), r = k(e), l(h.$$.fragment, e), G = k(e), l(L.$$.fragment, e), S = k(e), l(D.$$.fragment, e), I = k(e), l(F.$$.fragment, e), P = k(e), l(j.$$.fragment, e), q = k(e), l(M.$$.fragment, e), Z = k(e), l(N.$$.fragment, e), H = k(e), l(z.$$.fragment, e), this.h()
        },
        h() {
            _(t, "name", "description"), _(t, "content", re()), _(m, "property", "og:type"), _(m, "content", "article"), _(n, "property", "og:title"), _(n, "content", ne()), _(i, "property", "og:description"), _(i, "content", re()), _(u, "property", "og:url"), _(u, "content", "https://www.crftd.nl/venturedge"), _(c, "property", "og:image"), _(c, "content", "/opengraph/crftd-og-image.png"), _(v, "property", "og:site_name"), _(v, "content", "CRFTD"), _(T, "rel", "canonical"), _(T, "href", "https://www.crftd.nl/venturedge"), _(a, "name", "robots"), _(a, "content", "index, follow"), _(w, "name", "author"), _(w, "content", "CRFTD")
        },
        m(e, s) {
            A(document.head, t), A(document.head, m), A(document.head, n), A(document.head, i), A(document.head, u), A(document.head, c), A(document.head, v), A(document.head, T), A(document.head, a), A(document.head, w), b(e, V, s), p(C, e, s), b(e, r, s), p(h, e, s), b(e, G, s), p(L, e, s), b(e, S, s), p(D, e, s), b(e, I, s), p(F, e, s), b(e, P, s), p(j, e, s), b(e, q, s), p(M, e, s), b(e, Z, s), p(N, e, s), b(e, H, s), p(z, e, s), O = !0
        },
        p(e, [s]) {
            const W = {};
            s & 1 && (W.$$scope = {
                dirty: s,
                ctx: e
            }), L.$set(W);
            const Y = {};
            s & 1 && (Y.$$scope = {
                dirty: s,
                ctx: e
            }), D.$set(Y);
            const J = {};
            s & 1 && (J.$$scope = {
                dirty: s,
                ctx: e
            }), F.$set(J);
            const X = {};
            s & 1 && (X.$$scope = {
                dirty: s,
                ctx: e
            }), j.$set(X);
            const ee = {};
            s & 1 && (ee.$$scope = {
                dirty: s,
                ctx: e
            }), M.$set(ee);
            const te = {};
            s & 1 && (te.$$scope = {
                dirty: s,
                ctx: e
            }), N.$set(te)
        },
        i(e) {
            O || (g(C.$$.fragment, e), g(h.$$.fragment, e), g(L.$$.fragment, e), g(D.$$.fragment, e), g(F.$$.fragment, e), g(j.$$.fragment, e), g(M.$$.fragment, e), g(N.$$.fragment, e), g(z.$$.fragment, e), O = !0)
        },
        o(e) {
            f(C.$$.fragment, e), f(h.$$.fragment, e), f(L.$$.fragment, e), f(D.$$.fragment, e), f(F.$$.fragment, e), f(j.$$.fragment, e), f(M.$$.fragment, e), f(N.$$.fragment, e), f(z.$$.fragment, e), O = !1
        },
        d(e) {
            e && ($(V), $(r), $(G), $(S), $(I), $(P), $(q), $(Z), $(H)), $(t), $(m), $(n), $(i), $(u), $(c), $(v), $(T), $(a), $(w), d(C, e), d(h, e), d(L, e), d(D, e), d(F, e), d(j, e), d(M, e), d(N, e), d(z, e)
        }
    }
}
class et extends se {
    constructor(t) {
        super(), ue(this, t, null, Oe, ae, {})
    }
}
export {
    et as component
};
